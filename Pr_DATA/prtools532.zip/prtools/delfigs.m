%DELFIGS Delete all figures

delete(get(0,'children'))