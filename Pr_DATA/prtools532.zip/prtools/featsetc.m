%FEATSETC Set classifier

% Copyright: R.P.W. Duin, r.p.w.duin@37steps.com
% Faculty EWI, Delft University of Technology
% P.O. Box 5031, 2600 GA Delft, The Netherlands

function [out1,out2] = featsetc(a,objclassf,fsetindex,fsetcombc,fsetclassf,fsetlab)

error('featsetc has been replaced by bagc')
	
	
	
	
	