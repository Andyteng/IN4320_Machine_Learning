function b=loadobj(a)

	b=primport(a);

	return
