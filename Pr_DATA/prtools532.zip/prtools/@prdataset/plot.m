%PLOT Dataset overload (generates error)

function plot(varargin)

	
	error('Use for displaying datasets SCATTERD or SHOW')

return