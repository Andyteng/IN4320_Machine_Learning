%ISNAN Dataset overload

function n = isnan(a)
		n = isnan(a.data);

