%CEIL Dataset overload

function c = ceil(a)

	d = ceil(a.data);
	c = setdata(a,d);

return
