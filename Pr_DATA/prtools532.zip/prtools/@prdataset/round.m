%ROUND Dataset overload

function c = round(a)

	d = round(a.data);
	c = setdata(a,d);

return
