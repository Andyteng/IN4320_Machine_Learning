%LENGTH Dataset overload

% $Id: length.m,v 1.3 2007/03/22 07:45:54 duin Exp $

function l = length(a)

		l = size(a,1);

return;

