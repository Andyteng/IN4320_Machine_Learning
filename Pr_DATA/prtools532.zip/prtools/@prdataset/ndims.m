%NDIMS Dataset overload
function n = ndims(a)
n = 2;
return

