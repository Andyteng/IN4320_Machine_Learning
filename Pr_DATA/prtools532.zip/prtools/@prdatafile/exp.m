%EXP Datafile overload

function c = exp(a)
	
		
	c = a*filtm([],'exp');

return
