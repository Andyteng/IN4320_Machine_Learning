%SETTYPE Set TYPE datafile field

% Copyright: R.P.W. Duin, r.p.w.duin@37steps.com
% Faculty EWI, Delft University of Technology
% P.O. Box 5031, 2600 GA Delft, The Netherlands

function a = settype(a,s)

	  
  a.type = s;
  
 return
