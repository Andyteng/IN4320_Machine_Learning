%SQRT Datafile overload

function a = sqrt(a)
	
	  
	a = a*filtm([],'sqrt');
		
return
