%NOT Logical NOT. Datafile overload

function a = not(a)
				a = a*filtm([],'not');
return
