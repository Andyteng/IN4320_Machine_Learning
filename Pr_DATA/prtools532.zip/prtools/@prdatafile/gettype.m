%GETTYPE Get datafile TYPE field
%
%	   R = GETTYPE(A)

function r = gettype(a)

		
  r = a.type;
  
return