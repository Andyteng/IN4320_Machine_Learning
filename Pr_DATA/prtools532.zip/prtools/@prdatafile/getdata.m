%GETDATA Get data of datafile

function d = getdata(a)
	
		
	d = getdata(prdataset(a));

return
