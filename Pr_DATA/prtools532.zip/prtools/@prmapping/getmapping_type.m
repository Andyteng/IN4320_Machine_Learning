%GETMAPPING_TYPE Get mapping_type field in mapping
%
%     MAPPING_TYPE = GETMAPPING_TYPE(W)
%
% See HELP MAPPING_TYPE for more onformation on mapping types.

% $Id: getmapping_type.m,v 1.2 2006/03/08 22:06:58 duin Exp $

function mapping_type = getmapping_type(w)

		
mapping_type = w.mapping_type;
return
