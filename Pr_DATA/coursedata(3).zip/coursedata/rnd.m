%RND 200 objects with 2 features
%
%    X = RND;
%
% The random dataset is an artificial dataset containing only noise.
%
% SEE AlSO
% PRDATASET

function x = rnd

prload('rnd');
x = setname(a,'Random');


